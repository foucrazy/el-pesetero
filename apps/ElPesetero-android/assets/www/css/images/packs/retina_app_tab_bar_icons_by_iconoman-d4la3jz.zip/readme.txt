
Retina App Tab Bar Icons

Retina App Tab Bar Icons offer iPhone, iPad, and iPod developers a
quick and easy way to create stunning navigation bars, toolbars, and
tab bars in their apps. Numerous raster options are available to
accommodate the latest super-high resolution Retina displays used
in iPhone 4 and similar Apple devices. Thanks to the high-pixel count
and scalable vector versions available, Retina App Tab Bar Icons
will look edgy and three-dimensional. All icons have controllable
depth that can be adjusted with an extra Alpha-channel layer.
The Retina App Tab Bar Icons collection includes images one's 
likely to encounter in toolbars and navigation bars used in iPhone,
iPad, and iPod apps.

Technically, developers receive unique app icons drawn in matching
style, each coming in black and white versions. Resolutions of 
20x20, 30x30, 40x40, and 60x60 pixels in PNG and PSD formats are included.
Source images are distributed in SVG and AI formats.

Demo set includes 3 icons.

Price: $49.00 /39.00 EUR


You can view the entire icon set at the product page:
http://www.sibcode.com/stock-icons/retina-app-tab-bar-icons.htm

Download demo:
http://www.sibcode.com/downloads/retina-app-tab-bar-icons.zip
http://www.icon-files.com/downloads/retina-app-tab-bar-icons.zip


License Agreement

By purchasing icons and images from SibCode, You (the purchaser)
agree to the terms of this agreement, as detailed below. 

You may use the images from SibCode in commercial and
personal design projects, software or Internet products.
The images can be displayed in documentation, help files, and
advertising materials. You are free to sell and distribute
products and projects using purchased images without further
royalty fees. 

All image files are provided 'as is'. SibCode cannot be
held liable for any negative issues that may occur as a
result of using the images. 

You agree that all ownership and copyright of the images
remains the property of SibCode. You may not resell,
distribute, lease, license or sub-license the images or
modified images (or a subset of the images), to any third
party unless they are incorporated into your software or
design products. 

If you have any questions regarding copyright or licensing,
including whether another license is required for icon use
within products, please contact us here: www.sibcode.com/support.htm 


Icon Design Service

We can design custom images and web elements for you. Please find
the basic information about ordering icons, pricing and the portfolio 
here: http://www.aha-soft.com/icon-design.htm


Support page: http://www.sibcode.com/support.htm

Copyright � 2007-2011 SibCode. All rights reserved. 